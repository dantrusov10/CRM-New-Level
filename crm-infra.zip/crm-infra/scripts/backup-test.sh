#!/bin/bash
# Verify that PostgreSQL backups exist and list the latest ones.

set -euo pipefail

BACKUP_DIR=${BACKUP_DIR:-./backups}

echo "Listing backups in $BACKUP_DIR..."
ls -lh "$BACKUP_DIR" || { echo "Backup directory not found"; exit 1; }