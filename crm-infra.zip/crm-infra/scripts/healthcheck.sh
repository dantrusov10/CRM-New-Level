#!/bin/bash
# Simple health check script for the Sales Intelligence Hub.
#
# This script pings the API health endpoint and prints a status message.

set -euo pipefail

API_URL=${API_URL:-http://localhost/api/health}

echo "Checking API at $API_URL..."

status=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL")

if [ "$status" = "200" ]; then
  echo "✅ API is healthy"
else
  echo "❌ API returned status $status"
  exit 1
fi